# Takes the standardized claims data and adds important calculated columns that show how claims
# develop over time. Calculates "loss development factors" (ratios showing how much claims grow
# from one period to the next) and weights for each calculation.

"""
goal: Add calculated columns needed for chain ladder. These should typically not be changed, they should work with the format of the data output by 1-prep-data.py.
contents:
    enhance_triangle_data(): Add calculated columns (prior_age, ldf, weight) to the long format triangle data.

run-note: When copied to a project, run from the scripts/ directory:
    cd scripts/
    python 1b-calculate-ldfs.py
"""

import pandas as pd
import numpy as np

from modules import config

# Paths from modules/config.py — override here if needed:
OUTPUT_PATH = config.PROCESSED_DATA
METHOD_ID   = "chainladder"


def enhance_triangle_data(df_long: pd.DataFrame) -> pd.DataFrame:
    """
    Enhance triangle data by adding prior_age, ldf, and weight columns.
    
    For each (period, measure, source) combination:
    - prior_age: The previous development age
    - ldf: Loss Development Factor (current value / prior value)
    - weight: Volume weight for the LDF (equals prior value)
    
    The first age for each group will have NA values for these columns.
    
    Args:
        df_long: Long format DataFrame with columns: period, age, value, measure, source
                 Should come from 1-data-prep.py output
    
    Returns:
        DataFrame with additional columns: prior_age, ldf, weight, interval
    """
    # Make a copy to avoid modifying original
    df_enhanced = df_long.copy()
    
    # Get the age categories to map previous age
    ages = df_enhanced['age'].cat.categories.tolist()
    
    # Sort by grouping keys and age to ensure proper order
    # Use categorical codes for age to ensure correct ordering
    df_enhanced['_age_sort'] = df_enhanced['age'].cat.codes
    df_enhanced = df_enhanced.sort_values(['measure', 'source', 'period', '_age_sort'])
    df_enhanced = df_enhanced.drop(columns=['_age_sort']).reset_index(drop=True)
    
    # Group by period, measure, and source
    grouping_cols = ['period', 'measure', 'source']
    
    # Within each group, shift age and value to get prior values
    df_enhanced['prior_age'] = df_enhanced.groupby(grouping_cols, observed=True)['age'].shift(1)
    df_enhanced['prior_value'] = df_enhanced.groupby(grouping_cols, observed=True)['value'].shift(1)
    
    # Calculate LDF: current value / prior value
    df_enhanced['ldf'] = df_enhanced['value'] / df_enhanced['prior_value'].replace(0, np.nan)
    
    # Weight is the prior value (used for volume-weighted averages)
    df_enhanced['weight'] = df_enhanced['prior_value']
    
    # Drop the temporary prior_value column
    df_enhanced = df_enhanced.drop(columns=['prior_value'])

    # Create interval label for convenience (e.g., "12-24")
    df_enhanced['interval'] = df_enhanced.apply(
        lambda row: f"{row['prior_age']}-{row['age']}" if pd.notna(row['prior_age']) else None,
        axis=1
    )
    
    # Convert interval to categorical with proper ordering based on age sequence
    # Get all valid intervals in order by iterating through consecutive age pairs
    valid_intervals = []
    for i in range(len(ages) - 1):
        valid_intervals.append(f"{ages[i]}-{ages[i+1]}")
    
    df_enhanced['interval'] = pd.Categorical(
        df_enhanced['interval'],
        categories=valid_intervals,
        ordered=True
    )
    
    return df_enhanced


if __name__ == "__main__":  # pragma: no cover
    """Test the enhance_triangle_data function."""
    # Read prepped data from step 1
    input_file = OUTPUT_PATH + f"1_triangles.csv"
    # dtype=str prevents pandas from inferring numeric dtypes for columns that contain NaN
    # (e.g. age=None for Exposure rows), which would turn "12" into "12.0" after astype(str).
    df = pd.read_csv(input_file, dtype={'age': str, 'period': str})
    # CSV doesn't preserve ordered categorical dtype. Reconstruct from first-occurrence order in
    # the file, which matches the row order written by 1a (user controls input order there).
    # Downstream code calls .cat.categories to get the label list for intervals and sort keys.
    _age_order = list(dict.fromkeys(df['age'].dropna()))
    _period_order = list(dict.fromkeys(df['period'].dropna()))
    df['age'] = pd.Categorical(df['age'], categories=_age_order, ordered=True)
    df['period'] = pd.Categorical(df['period'], categories=_period_order, ordered=True)
    print(f"Loaded {len(df)} rows, {df['measure'].nunique()} measures, {df['source'].nunique()} sources")
    
    # Enhance the data
    df_enhanced = enhance_triangle_data(df)
    print(f"\nEnhanced data: {len(df_enhanced)} rows, {df_enhanced['ldf'].notna().sum()} with LDFs")
    
    # Display sample
    pd.set_option('display.max_columns', None)
    pd.set_option('display.width', None)
    print("\nSample (first 10 rows with LDFs):")
    print(df_enhanced[df_enhanced['ldf'].notna()].head(10))
    
    # Round numeric columns to 4 decimal places
    numeric_cols = ['value', 'ldf', 'weight']
    for col in numeric_cols:
        if col in df_enhanced.columns:
            df_enhanced[col] = df_enhanced[col].round(4)
    
    # Save outputs
    df_enhanced.to_csv(OUTPUT_PATH + f"2_enhanced.csv", index=False)
    print(f"\nSaved to: {OUTPUT_PATH}2_enhanced.csv")

